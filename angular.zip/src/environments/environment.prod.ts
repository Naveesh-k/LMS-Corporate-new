export const environment = {
  production: true,
  lmsApiBaseUrl: 'http://a4f746274c96.ngrok.io/api/v1/eduTech/',
};
