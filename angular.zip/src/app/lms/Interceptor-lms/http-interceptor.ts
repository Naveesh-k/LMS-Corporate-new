export interface HttpInterceptor {
}
